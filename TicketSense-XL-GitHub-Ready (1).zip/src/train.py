import os
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report

DATA_PATH = "data/tickets.csv"
MODEL_DIR = "models"

def load_dataset():
    if not os.path.exists(DATA_PATH):
        raise FileNotFoundError(f"Dataset not found: {DATA_PATH}")
    df = pd.read_csv(DATA_PATH)
    print("Dataset loaded successfully.")
    print("Rows:", len(df))
    print("Columns:", list(df.columns))
    return df

def clean_text(text):
    return str(text).lower().strip()

def main():
    df = load_dataset()
    text_column = "Ticket Description"
    target_column = "Ticket Priority"

    if text_column not in df.columns:
        raise ValueError(f"Column '{text_column}' not found in dataset.")
    if target_column not in df.columns:
        raise ValueError(f"Column '{target_column}' not found in dataset.")

    df = df[[text_column, target_column]].dropna()
    df[text_column] = df[text_column].apply(clean_text)

    X = df[text_column]
    y = df[target_column]

    encoder = LabelEncoder()
    y_encoded = encoder.fit_transform(y)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y_encoded, test_size=0.20, random_state=42, stratify=y_encoded
    )

    vectorizer = TfidfVectorizer(
        max_features=5000, stop_words="english", ngram_range=(1, 2)
    )
    X_train_tfidf = vectorizer.fit_transform(X_train)
    X_test_tfidf = vectorizer.transform(X_test)

    model = LogisticRegression(max_iter=1000, random_state=42)
    model.fit(X_train_tfidf, y_train)

    y_pred = model.predict(X_test_tfidf)

    print("\n==============================")
    print("TicketSense-XL Results")
    print("==============================")
    print(f"\nAccuracy: {accuracy_score(y_test, y_pred):.4f}")
    print("\nClassification Report:")
    print(classification_report(
        y_test, y_pred, target_names=encoder.classes_, zero_division=0
    ))

    os.makedirs(MODEL_DIR, exist_ok=True)
    joblib.dump(model, "models/model.pkl")
    joblib.dump(vectorizer, "models/tfidf_vectorizer.pkl")
    joblib.dump(encoder, "models/label_encoder.pkl")
    print("\nModel files saved successfully.")

if __name__ == "__main__":
    main()
