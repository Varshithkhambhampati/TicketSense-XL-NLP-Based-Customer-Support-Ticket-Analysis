import os
import joblib

MODEL_PATH = "models/model.pkl"
VECTORIZER_PATH = "models/tfidf_vectorizer.pkl"
ENCODER_PATH = "models/label_encoder.pkl"

def load_models():
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError("Model not found. Run train.py first.")
    return (
        joblib.load(MODEL_PATH),
        joblib.load(VECTORIZER_PATH),
        joblib.load(ENCODER_PATH),
    )

def predict_ticket(ticket):
    model, vectorizer, encoder = load_models()
    ticket = str(ticket).lower().strip()
    ticket_vector = vectorizer.transform([ticket])
    prediction = model.predict(ticket_vector)
    return encoder.inverse_transform(prediction)[0]

def main():
    print("==============================")
    print("TicketSense-XL Prediction")
    print("==============================")
    ticket = input("\nEnter customer support ticket:\n")
    if not ticket.strip():
        print("Please enter a valid ticket.")
        return
    print("\nPredicted Ticket Priority:", predict_ticket(ticket))

if __name__ == "__main__":
    main()
