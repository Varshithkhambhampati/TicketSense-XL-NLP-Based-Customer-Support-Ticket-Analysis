import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report
)

DATA_PATH = "data/tickets.csv"

def main():
    df = pd.read_csv(DATA_PATH)
    text_column = "Ticket Description"
    target_column = "Ticket Priority"
    df = df[[text_column, target_column]].dropna()

    X = df[text_column].astype(str).str.lower().str.strip()
    y = df[target_column]

    model = joblib.load("models/model.pkl")
    vectorizer = joblib.load("models/tfidf_vectorizer.pkl")
    encoder = joblib.load("models/label_encoder.pkl")

    y_encoded = encoder.transform(y)

    _, X_test, _, y_test = train_test_split(
        X, y_encoded, test_size=0.20, random_state=42, stratify=y_encoded
    )

    y_pred = model.predict(vectorizer.transform(X_test))

    print("\n===== Evaluation Results =====")
    print("Accuracy:", accuracy_score(y_test, y_pred))
    print("Precision:", precision_score(y_test, y_pred, average="weighted", zero_division=0))
    print("Recall:", recall_score(y_test, y_pred, average="weighted", zero_division=0))
    print("F1 Score:", f1_score(y_test, y_pred, average="weighted", zero_division=0))
    print("\nConfusion Matrix:")
    print(confusion_matrix(y_test, y_pred))
    print("\nClassification Report:")
    print(classification_report(
        y_test, y_pred, target_names=encoder.classes_, zero_division=0
    ))

if __name__ == "__main__":
    main()
