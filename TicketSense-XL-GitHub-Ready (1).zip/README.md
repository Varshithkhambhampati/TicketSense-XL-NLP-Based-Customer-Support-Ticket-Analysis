# TicketSense-XL: NLP-Based Customer Support Ticket Analysis

TicketSense-XL is an NLP and machine learning project that analyzes customer support tickets and predicts ticket priority.

## Technologies
- Python
- Pandas
- NumPy
- Scikit-learn
- TF-IDF
- Logistic Regression
- Joblib

## Project Structure
- `data/tickets.csv` - dataset
- `src/train.py` - train the model
- `src/predict.py` - predict a new ticket
- `src/evaluate.py` - evaluate the model
- `requirements.txt` - dependencies

## Required Dataset Columns
The CSV should contain:
- `Ticket Description`
- `Ticket Priority`

## Run
```bash
pip install -r requirements.txt
python src/train.py
python src/evaluate.py
python src/predict.py
```

## Workflow
Customer Support Ticket -> Text Preprocessing -> TF-IDF -> Machine Learning -> Ticket Priority Prediction

## Author
K. Varshith
B.Tech Artificial Intelligence and Machine Learning
Kommuri Pratap Reddy Institute of Technology
